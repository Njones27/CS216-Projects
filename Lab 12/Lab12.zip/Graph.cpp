/* File: Graph.cpp
 * Course: CS216-003
 * Project: Lab 12
 * Purpose: the implementation of member functions for the Graph class.
 * Author: Nathan Jones
 */

#include <iostream>
#include "Graph.h"

#include <queue>

Graph::Graph()
{
    // Default constructor
}

// to check if an edge exists between v and w
bool Graph::hasEdge(char v, char w) const {
    // Check if vertex v exists in the adjacency map
    if (adjMap.find(v) == adjMap.end()) {
        return false;
    }
    // Check if w is in the set of vertices adjacent to v
    return adjMap.at(v).find(w) != adjMap.at(v).end();
}

// to add an edge beween v and w to the graph
void Graph::addEdge(char v, char w) {
    // Add w to the set of vertices adjacent to v
    adjMap[v].insert(w);

    // Add v to the set of vertices adjacent to w
    adjMap[w].insert(v);
}

int Graph::BFS(char s, char t, map<char, int>& distance, map<char, char>& go_through) const {
    // Check if source or target vertices exist
    if (adjMap.find(s) == adjMap.end() || adjMap.find(t) == adjMap.end()) {
        return INVALID_VERTEX;
    }
    // Initialize BFS data structures
    queue<char> q;
    set<char> visited;
    
    // Start BFS from source
    q.push(s);
    visited.insert(s);
    distance[s] = 0;
    
    while (!q.empty()) {
        char current = q.front();
        q.pop();
        
        // Check all adjacent vertices
        for (char neighbor : adjMap.at(current)) {
            if (visited.find(neighbor) == visited.end()) {
                // Mark as visited
                visited.insert(neighbor);
                // Set distance
                distance[neighbor] = distance[current] + 1;
                // Set the vertex to go through
                go_through[neighbor] = current;
                // Add to queue
                q.push(neighbor);
                
                // If we found the target, we can continue processing
                // to find other possible paths of the same length
                if (neighbor == t) {
                    continue;
                }
            }
        }
    }
    
    // Check if we reached the target
    if (visited.find(t) == visited.end()) {
        return NOPATH;
    }   

    return distance[t];
}
